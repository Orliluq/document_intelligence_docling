## Informe de retroalimentación comunitaria

Documento de demostración para extracción estructural con Docling

## 1. Contexto

Este informe reúne comentarios ficticios de una comunidad tecnológica. El objetivo del ejercicio es convertir un PDF en datos que puedan consultarse, analizarse y reutilizarse en una aplicación.

Un PDF puede contener texto seleccionable, elementos gráficos y tablas. La posición de cada elemento aporta información sobre su función y sobre el orden en que debería leerse.

## 2. Indicadores mensuales

| Mes     |   Comentarios |   Positivos |   Neutrales |   Negativos |
|---------|---------------|-------------|-------------|-------------|
| Enero   |           120 |          72 |          30 |          18 |
| Febrero |           150 |          90 |          35 |          25 |
| Marzo   |           138 |          83 |          32 |          23 |
| Abril   |           171 |         110 |          38 |          23 |

## 3. Visualización

El gráfico representa la evolución mensual de los comentarios positivos, neutrales y negativos. En un flujo documental real, la detección de una figura no significa que su contenido ya haya sido interpretado semánticamente.

<!-- image -->

## 4. Nota metodológica

Los valores de esta muestra son ficticios. Antes de usar datos extraídos en un proceso de negocio, verifica visualmente el PDF original y contrasta las cifras con una fuente confiable.